export type TFile = {
    id: string;
    kind: string;
    name: string;
    mimeType: string;
    size: string;
}
